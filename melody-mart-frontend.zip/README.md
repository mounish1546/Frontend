# Melody Mart Frontend

## Run
Open `home.html` in a browser, or use VS Code + Live Server.

## Pages
- login.html
- register.html
- home.html
- products.html
- cart.html
- checkout.html
- profile.html

## Notes
This is a frontend-only demo. Registration, login, cart, and checkout demo data use browser localStorage.
Passwords are NOT securely stored; connect the forms to a Java/Spring Boot backend before using this as a real e-commerce application.
