
const products = [
 {id:1,name:"Acoustic Guitar",category:"Guitars",price:7999,old:8999,icon:"🎸",rating:4.8},
 {id:2,name:"Electric Guitar",category:"Guitars",price:12999,old:14999,icon:"🎸",rating:4.7},
 {id:3,name:"Digital Piano",category:"Keyboards",price:18999,old:21999,icon:"🎹",rating:4.9},
 {id:4,name:"Classic Violin",category:"Strings",price:6499,old:7499,icon:"🎻",rating:4.6},
 {id:5,name:"Drum Set",category:"Drums",price:22999,old:25999,icon:"🥁",rating:4.8},
 {id:6,name:"Saxophone",category:"Wind",price:15999,old:17999,icon:"🎷",rating:4.5},
 {id:7,name:"Trumpet",category:"Wind",price:8999,old:9999,icon:"🎺",rating:4.6},
 {id:8,name:"Ukulele",category:"Strings",price:3499,old:3999,icon:"🎸",rating:4.7},
 {id:9,name:"Electronic Keyboard",category:"Keyboards",price:10999,old:12999,icon:"🎹",rating:4.8},
 {id:10,name:"Cajon",category:"Percussion",price:2999,old:3499,icon:"🪘",rating:4.5},
 {id:11,name:"Flute",category:"Wind",price:2499,old:2999,icon:"🎶",rating:4.4},
 {id:12,name:"Bass Guitar",category:"Guitars",price:13999,old:15999,icon:"🎸",rating:4.8}
];

const money = n => "₹" + Number(n).toLocaleString("en-IN");
const getCart = () => JSON.parse(localStorage.getItem("melodyCart") || "[]");
const saveCart = c => { localStorage.setItem("melodyCart", JSON.stringify(c)); updateCartCount(); };
function updateCartCount(){
 const count=getCart().reduce((s,i)=>s+i.qty,0);
 document.querySelectorAll(".cart-count").forEach(e=>e.textContent=count);
}
function toast(msg){
 const t=document.querySelector(".toast"); if(!t)return;
 t.textContent=msg;t.style.display="block";setTimeout(()=>t.style.display="none",1800);
}
function addToCart(id){
 const p=products.find(x=>x.id===id); if(!p)return;
 let cart=getCart(), item=cart.find(x=>x.id===id);
 if(item)item.qty++; else cart.push({...p,qty:1});
 saveCart(cart);toast(p.name+" added to cart");
}
function changeQty(id,delta){
 let cart=getCart(), item=cart.find(x=>x.id===id);
 if(!item)return;
 item.qty+=delta; if(item.qty<=0)cart=cart.filter(x=>x.id!==id);
 saveCart(cart);renderCart();
}
function removeItem(id){saveCart(getCart().filter(x=>x.id!==id));renderCart();}

function productCard(p){
 return `<article class="product-card">
   <div class="product-img">${p.icon}</div>
   <div class="product-body">
    <span class="badge">${p.category}</span>
    <h3>${p.name}</h3>
    <div class="rating">★★★★★ <span class="muted">(${p.rating})</span></div>
    <div><span class="price">${money(p.price)}</span><span class="old-price">${money(p.old)}</span></div>
    <div class="card-actions"><a class="btn btn-outline" href="products.html?id=${p.id}">View</a><button class="btn btn-dark" onclick="addToCart(${p.id})">Add</button></div>
   </div>
 </article>`;
}
function renderFeatured(){
 const el=document.querySelector("#featured-products"); if(el)el.innerHTML=products.slice(0,8).map(productCard).join("");
}
function renderProducts(){
 const grid=document.querySelector("#products-grid"); if(!grid)return;
 const search=(document.querySelector("#search")?.value||"").toLowerCase();
 const cat=document.querySelector("#category")?.value||"All";
 const sort=document.querySelector("#sort")?.value||"default";
 let list=products.filter(p=>(p.name+" "+p.category).toLowerCase().includes(search)&&(cat==="All"||p.category===cat));
 if(sort==="low")list.sort((a,b)=>a.price-b.price);
 if(sort==="high")list.sort((a,b)=>b.price-a.price);
 if(sort==="rating")list.sort((a,b)=>b.rating-a.rating);
 grid.innerHTML=list.length?list.map(productCard).join(""):`<div class="empty" style="grid-column:1/-1">No products found.</div>`;
}
function renderCart(){
 const box=document.querySelector("#cart-items"); if(!box)return;
 const cart=getCart();
 if(!cart.length){box.innerHTML=`<div class="empty"><div style="font-size:55px">🛒</div><h3>Your cart is empty</h3><p>Browse instruments and add your favourites.</p><br><a class="btn btn-dark" href="products.html">Shop Now</a></div>`;updateSummary(0);return;}
 box.innerHTML=cart.map(i=>`<div class="cart-item">
  <div class="cart-thumb">${i.icon}</div>
  <div><h3>${i.name}</h3><p class="muted">${i.category}</p><div class="qty"><button onclick="changeQty(${i.id},-1)">−</button><span>${i.qty}</span><button onclick="changeQty(${i.id},1)">+</button></div></div>
  <div style="text-align:right"><strong>${money(i.price*i.qty)}</strong><br><button class="btn btn-danger" style="padding:6px 10px;margin-top:7px" onclick="removeItem(${i.id})">Remove</button></div>
 </div>`).join("");
 updateSummary(cart.reduce((s,i)=>s+i.price*i.qty,0));
}
function updateSummary(sub){
 const shipping=sub>0&&sub<5000?199:0, total=sub+shipping;
 const s=document.querySelector("#subtotal"), sh=document.querySelector("#shipping"), t=document.querySelector("#total");
 if(s)s.textContent=money(sub);if(sh)sh.textContent=money(shipping);if(t)t.textContent=money(total);
}
function renderCheckout(){
 const cart=getCart(), list=document.querySelector("#checkout-items");if(!list)return;
 if(!cart.length){list.innerHTML=`<p class="muted">Your cart is empty. <a href="products.html" style="color:#8a641c">Shop now</a>.</p>`;updateSummary(0);return;}
 list.innerHTML=cart.map(i=>`<div class="summary-row"><span>${i.name} × ${i.qty}</span><strong>${money(i.price*i.qty)}</strong></div>`).join("");
 updateSummary(cart.reduce((s,i)=>s+i.price*i.qty,0));
}
function completeOrder(e){
 e.preventDefault();
 if(!getCart().length){toast("Your cart is empty");return;}
 const orderId="MM"+Date.now().toString().slice(-7);
 localStorage.setItem("lastOrder",orderId);localStorage.removeItem("melodyCart");updateCartCount();
 document.querySelector("#order-message").innerHTML=`<div class="alert success" style="display:block"><strong>Order placed successfully!</strong><br>Order ID: ${orderId}. Thank you for shopping with Melody Mart.</div>`;
 document.querySelector("#checkout-form").reset();renderCheckout();
}
function register(e){
 e.preventDefault();
 const name=document.querySelector("#regName").value.trim(), email=document.querySelector("#regEmail").value.trim(), pass=document.querySelector("#regPassword").value;
 const confirm=document.querySelector("#regConfirm").value, alert=document.querySelector("#register-alert");
 if(pass.length<6){alert.className="alert error";alert.style.display="block";alert.textContent="Password must be at least 6 characters.";return;}
 if(pass!==confirm){alert.className="alert error";alert.style.display="block";alert.textContent="Passwords do not match.";return;}
 localStorage.setItem("melodyUser",JSON.stringify({name,email}));alert.className="alert success";alert.style.display="block";alert.textContent="Registration successful! Redirecting to login...";
 setTimeout(()=>location.href="login.html",900);
}
function login(e){
 e.preventDefault();
 const email=document.querySelector("#loginEmail").value.trim(), pass=document.querySelector("#loginPassword").value, saved=JSON.parse(localStorage.getItem("melodyUser")||"null"), alert=document.querySelector("#login-alert");
 if(saved && saved.email===email && pass.length>=6){localStorage.setItem("loggedIn","true");location.href="home.html";return;}
 if(!saved){alert.textContent="No account found. Please register first.";}else{alert.textContent="Invalid email or password.";}
 alert.className="alert error";alert.style.display="block";
}
function loadProfile(){
 const user=JSON.parse(localStorage.getItem("melodyUser")||"null");
 if(!user)return;
 document.querySelectorAll("[data-user-name]").forEach(e=>e.textContent=user.name);
 document.querySelectorAll("[data-user-email]").forEach(e=>e.textContent=user.email);
 const initial=document.querySelector("#avatar");if(initial)initial.textContent=user.name.charAt(0).toUpperCase();
}
function logout(){localStorage.removeItem("loggedIn");location.href="login.html";}
document.addEventListener("DOMContentLoaded",()=>{
 updateCartCount();renderFeatured();renderProducts();renderCart();renderCheckout();loadProfile();
 document.querySelector("#register-form")?.addEventListener("submit",register);
 document.querySelector("#login-form")?.addEventListener("submit",login);
 document.querySelector("#checkout-form")?.addEventListener("submit",completeOrder);
 document.querySelector("#search")?.addEventListener("input",renderProducts);
 document.querySelector("#category")?.addEventListener("change",renderProducts);
 document.querySelector("#sort")?.addEventListener("change",renderProducts);
 document.querySelector("#menu-btn")?.addEventListener("click",()=>document.querySelector(".nav-links")?.classList.toggle("open"));
});
